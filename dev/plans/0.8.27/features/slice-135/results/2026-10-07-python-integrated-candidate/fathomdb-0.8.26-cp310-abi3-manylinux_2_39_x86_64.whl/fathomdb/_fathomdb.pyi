"""Type stubs for the PyO3 extension `fathomdb._fathomdb`.

Mirrors the surface emitted by `src/rust/crates/fathomdb-py/src/lib.rs`.
Hand-maintained — keep in sync with the binding's `#[pyclass]` /
`create_exception!` / `#[pyfunction]` exports.
"""

from typing import Any, Iterable, Literal

from fathomdb.types import (
    DenseReadiness,
    EmbeddingOperation,
    EmbedderEvent,
    ProjectionRuntimeUnavailabilityReason,
    ProjectionStatusDenseReadiness,
)

class WriteReceipt:
    cursor: int
    row_cursors: list[int]
    dangling_edge_endpoints: int

class SourceDependencyV1:
    schema_version: int
    dependency_id: str
    source_revision_id: str
    derived_revision_id: str
    registered_dependency_generation: str

class DependencyListV1:
    schema_version: int
    items: list[SourceDependencyV1]

class ClosureProofV1:
    schema_version: int
    proof_write_boundary: str
    current_active_dependent_nodes: str
    current_derived_edges: str
    view_eligible_dependents: str
    ownerless_projection_rows: str
    post_admission_registrations: str
    remaining_dependency_rows: str | None
    remaining_canonical_rows: str | None
    remaining_projection_rows: str | None
    remaining_receipt_reference_rows: str | None

class ClosureStatusV1:
    schema_version: int
    closure_operation_id: str
    root_type: str
    source_revision_id: str | None
    source_id: str | None
    cause: str
    phase: str
    effective_at_epoch_s: str
    admitted_write_boundary: str
    admitted_dependency_generation: str
    affected_count: str
    blocker_code: str | None
    proof: ClosureProofV1 | None

class ActuationReceiptV1:
    schema_version: int
    operation_id: str
    request_sha256: str
    outcome: str
    refused_operation_index: int | None
    refused_field_path: str | None
    reason_codes: list[str]
    affected_revision_ids: list[str]
    resulting_write_boundary: str | None
    resulting_dependency_generation: str | None
    pending_projection_write_cursors: list[str]
    projection_generation_id: str | None
    closure_operation_ids: list[str]

class ProjectionGenerationStatusV1:
    schema_version: int
    generation_id: str
    declaration_sha256: str
    origin: str
    transition_boundary: str
    effective_at_epoch_s: int
    observed_boundary: str
    ready_through: str
    readiness: str
    runtime_state: str
    pending_count: str
    failed_count: str

class MutationProjectionStatusV1:
    schema_version: int
    operation_id: str
    write_cursor: str
    generation_id: str
    effective_at_epoch_s: int
    observed_boundary: str
    ready_through: str
    readiness: str
    runtime_state: str
    pending_count: str
    failed_count: str

class SoftFallback:
    branch: str

# C-2 (0.8.19 / TC-8) — typed id-space carrier for SearchHit.id.
class IdSpace:
    # "logical" | "content" | "passage"
    space: str
    # bare id value (id-space prefix stripped)
    value: str

class SearchHit:
    # C-2 (0.8.19 / TC-8) — typed, non-null, id-space-total hit id (subsumes the
    # pre-0.8.19 int write_cursor id AND the additive stable_id).
    id: IdSpace
    kind: str
    body: str
    score: float
    branch: str
    source_id: str | None
    # 0.8.5 (EXP-0) — CE score (sigmoid of the cross-encoder logit) for in-pool
    # reranked hits; None otherwise (out-of-pool, identity path, or no CE model).
    ce_score: float | None

class QueryTrace:
    # 0.8.8 EXP-OBS (Slice 10) — query-level retrieval trace.
    query_chars: int
    k: int
    rerank_depth: int
    pool_n: int
    alpha: float
    use_graph_arm: bool
    recency: bool
    embedder_id: str
    ce_active: bool
    vector_hits: int
    text_hits: int
    graph_hits: int
    dropped_edge_hits: int

class PerHitExplain:
    # 0.8.8 EXP-OBS (Slice 10) — per-hit provenance + score breakdown.
    id: int
    arm: str
    vector_rank: int | None
    text_rank: int | None
    graph_rank: int | None
    fused_score: float
    ce_score: float | None
    blended: float
    # 0.8.16 Slice 5 / F9 — node importance / edge confidence applied to this
    # hit's contribution (None = graceful-absent / neutral).
    importance: float | None
    confidence: float | None
    structural: StructuralInclusionV1

class StructuralInclusionV1:
    schema_version: int
    inclusion_state: str
    projection_origin: str
    dependency_state: str
    lifecycle_state: str
    degradation_codes: list[str]

class Explanation:
    # 0.8.8 EXP-OBS (Slice 10) — opt-in explanation sidecar.
    trace: QueryTrace
    per_hit: list[PerHitExplain]
    correlation_id: str

class SearchResult:
    projection_cursor: int
    soft_fallback: SoftFallback | None
    results: list[SearchHit]
    # Opt-in; None unless ordinary or frozen retrieval requests explanation.
    explanation: Explanation | None

class EvidenceSidecarEntryV1:
    schema_version: int
    result_index: int
    artifact_revision_id: str
    evidence_ref: str

class EvidenceSearchResultV1:
    schema_version: int
    search_result: SearchResult
    evidence: list[EvidenceSidecarEntryV1]

class EvidenceContributionV1:
    schema_version: int
    vector_rank: int | None
    text_rank: int | None
    graph_rank: int | None
    fused_score: float
    ce_score: float | None
    blended_score: float
    importance: float | None
    confidence: float | None

class EvidenceProjectionOriginV1:
    schema_version: int
    artifact_class: str
    representative_arm: str
    projection_generation_id: str
    graph_origin_kind: str | None
    graph_edge_artifact_revision_id: str | None
    graph_hop_count: int | None

class ResolvedEvidenceV1:
    schema_version: int
    logical_id: str | None
    artifact_revision_id: str
    source_id: str
    source_version_id: str
    source_revision_id: str
    locator_kind: str
    locator_start_inclusive: int | None
    locator_end_exclusive: int | None
    canonical_source_body: str
    evidence_text: str
    canonical_source_hash: str
    effective_valid_at: int
    artifact_lifecycle_kind: str
    artifact_lifecycle_state: str | None
    artifact_superseded: bool
    artifact_valid_at_effective: bool | None
    source_lifecycle_state: str
    projection_origin: EvidenceProjectionOriginV1
    retrieval_contribution: EvidenceContributionV1
    dependency: SourceDependencyV1 | None

class CounterSnapshot:
    queries: int
    writes: int
    write_rows: int
    admin_ops: int
    cache_hit: int
    cache_miss: int

class NodeRecord:
    logical_id: str
    kind: str
    body: str
    write_cursor: int

class ReadView:
    """0.8.20 Slice 10b (R-20-RV / R-20-NV) — read-mode / validity selector.

    Every field defaults to the STRICT view, so ``ReadView()`` is the shipped
    read behaviour. World-time only — no ``history_as_of``.
    """

    include_superseded: bool
    include_inactive: bool
    include_out_of_window: bool
    valid_as_of: int | None
    def __init__(
        self,
        include_superseded: bool = False,
        include_inactive: bool = False,
        include_out_of_window: bool = False,
        valid_as_of: int | None = None,
    ) -> None: ...

class ReadContextV1:
    schema_version: int
    def __init__(
        self,
        view: ReadView | None = ...,
        source_type: str | None = ...,
        kind: str | None = ...,
        created_after: int | None = ...,
        status: str | None = ...,
        attributes: list[tuple[str, str]] | None = ...,
        schema_version: int = ...,
    ) -> None: ...

class FrozenReadContextV1:
    schema_version: int
    effective_valid_at: int
    context: ReadContextV1
    token: str
    def __init__(
        self,
        effective_valid_at: int,
        context: ReadContextV1,
        token: str,
        schema_version: int = ...,
    ) -> None: ...

class BoundaryCrossing:
    node: NodeRecord
    became_valid_at: int | None
    became_invalid_at: int | None

class OpStoreRow:
    id: int
    collection: str
    record_key: str
    op_kind: str
    payload: str
    schema_id: str | None
    write_cursor: int

class OperationalStateRecordV1:
    schema_version: int
    collection: str
    record_key: str
    payload: str
    schema_id: str | None
    write_cursor: int

class NodePageV1:
    schema_version: int
    items: list[NodeRecord]
    next_cursor: str | None

class OperationalStatePageV1:
    schema_version: int
    items: list[OperationalStateRecordV1]
    next_cursor: str | None

class IngestWithExtractorReceipt:
    """G11 (Slice 15) — BYO-LLM ingest receipt."""

    nodes_written: int
    edges_written: int
    docs_processed: int

class ConsolidateReceipt:
    """0.8.12 Slice 15 (OPP-2) — consolidation / recency provider receipt."""

    clusters_processed: int
    edges_examined: int
    edges_kept: int
    edges_invalidated: int
    edges_superseded: int

class MigrationStepReport:
    step_id: int
    duration_ms: int | None
    failed: bool

class EmbedderIdentity:
    name: str
    revision: str
    dimension: int

class CudaDeviceInfo:
    ordinal: int
    uuid: str | None
    name: str | None
    driver_version: str | None
    compute_capability: str | None
    cuda_toolkit_version: str | None

class CudaVisibleDevice:
    visible_ordinal: int
    uuid: str
    name: str
    compute_capability: str | None

class EffectiveEmbedDevice:
    kind: str
    cuda_device: CudaDeviceInfo | None

class DeviceResolution:
    requested_policy: str
    cuda_compiled: bool
    effective_device: EffectiveEmbedDevice
    visible_cuda_devices: list[CudaVisibleDevice]
    selected_cuda_uuid: str | None
    reason: str | None

class GpuAllocationWitness:
    # 0.8.23 Slice 80.6 (D-80.6-6, R80-13) — the retained
    # `fathomdb.tegra-gpu-allocation-witness/v1` record. Every number the
    # verdict used is present so a reader re-derives it rather than trusting it.
    schema: str
    sole_gpu_consumer_precondition: str
    device_ordinal_requested: int
    device_ordinal_actual: int
    device_uuid: str
    device_name: str
    compute_capability: str
    free_before_bytes: int
    free_after_bytes: int
    total_bytes: int
    delta_bytes: int
    delta_floor_bytes: int
    control_allocation_request_bytes: int
    control_block_count: int
    control_free_before_bytes: int
    control_free_after_bytes: int
    control_delta_bytes: int
    embedded_vector_dim: int

class OpenReport:
    schema_version_before: int
    schema_version_after: int
    migration_steps: list[MigrationStepReport]
    embedder_warmup_ms: int
    query_backend: str
    default_embedder: EmbedderIdentity
    # EU-5a1/5a2/5b — surfaced by EU-6.
    embedder_download_ms: int | None
    embedder_events: list[EmbedderEvent]
    embedder_mean_centering_required: bool
    embedder_mean_vec_pinned: bool
    dense_disabled: bool
    dense_disabled_reason: str | None
    embedder_device_resolution: DeviceResolution | None
    reranker_device_resolution: DeviceResolution | None
    # `None` means no witness was taken, never "a witness measured nothing".
    embedder_gpu_allocation_witness: GpuAllocationWitness | None

class Engine:
    @staticmethod
    def open(
        path: str,
        use_default_embedder: bool = ...,
        config: dict[str, int | None] | None = ...,
    ) -> "Engine": ...
    # NOTE: `_configure_vector_kind_for_test`, `_write_vector_for_test`, and
    # `_set_legacy_projection_search_subobjects_for_test`
    # are intentionally NOT declared here. They only exist on the binary
    # when the `test-hooks` Cargo feature is enabled (see
    # `src/rust/crates/fathomdb-py/src/lib.rs::#[cfg(any(test, feature =
    # "test-hooks"))]`), and that feature is dev-only — it is not part of
    # the shipped wheel's feature axis (`pyproject.toml [tool.maturin]
    # features` and `release.yml` build-python's `args:`). Advertising
    # them on the public stub would imply they are callable by end users,
    # which is false.
    def open_report(self) -> OpenReport: ...
    def freeze_read_context(self, context: ReadContextV1) -> FrozenReadContextV1: ...
    def graph_expand(self, request_json: str) -> str: ...
    def trace_dependency(
        self,
        root_revision_id: str,
        direction: str,
        context: FrozenReadContextV1,
        max_relations: int = 100,
        max_work_units: int = 101,
    ) -> str: ...
    def validate_frozen_read_context(self, context: FrozenReadContextV1) -> None: ...
    def search_frozen(
        self,
        query: str,
        context: FrozenReadContextV1,
        rerank_depth: int = ...,
        use_graph_arm: bool = ...,
        alpha: float = ...,
        pool_n: int | None = ...,
        explain: bool = ...,
        limit: int = ...,
    ) -> SearchResult: ...
    def search_with_evidence(
        self,
        query: str,
        context: FrozenReadContextV1,
        rerank_depth: int = ...,
        use_graph_arm: bool = ...,
        alpha: float = ...,
        pool_n: int = ...,
        include_explanation: bool = ...,
        limit: int = ...,
    ) -> EvidenceSearchResultV1: ...
    def resolve_evidence(
        self,
        evidence_ref: str,
        context: FrozenReadContextV1,
    ) -> ResolvedEvidenceV1: ...
    def resolve_graph_evidence(
        self,
        evidence_ref: str,
        context: FrozenReadContextV1,
    ) -> str: ...
    def search_expand_frozen(
        self,
        query: str,
        context: FrozenReadContextV1,
        depth: int,
        limit: int = ...,
    ) -> SearchExpandResult: ...
    # Write items are loose mappings, not typed structs, so the stub cannot
    # express their shape. A NODE item accepts:
    #   kind: str (required)        body: str
    #   source_id: str (required, 0.8.20 R-20-E3)
    #   logical_id: str | None      state: "pending" | "active" | None
    #   reason: str | None
    #   valid_from: int | None      valid_until: int | None
    # 0.8.20 Slice 15b (TC-34): `valid_from`/`valid_until` are the world-time
    # validity window in INTEGER epoch SECONDS, half-open
    # [valid_from, valid_until). Absent/None = unbounded on that side, which is
    # the back-compat default (valid at every instant). `valid_from >=
    # valid_until` raises WriteValidationError, and so does a non-integer
    # bound (including bool) — ONE family for the whole write-validation
    # boundary (0.8.20 Slice 22, decision #18; this pair used to raise
    # InvalidArgumentError carrying both bounds). WriteValidationError is
    # message-less here, so the offending bounds are NOT recoverable from the
    # error — validate the pair before calling.
    # See `fathomdb.engine.Engine.write`.
    def write(self, batch: Iterable[Any]) -> WriteReceipt: ...
    def actuate(self, request: Any) -> ActuationReceiptV1: ...
    def register_source_dependency(self, request: Any) -> SourceDependencyV1: ...
    def dependencies_for_source(self, request: Any) -> DependencyListV1: ...
    def dependency_for_derived(self, request: Any) -> SourceDependencyV1 | None: ...
    def read_dependency_closure(self, request: Any) -> ClosureStatusV1 | None: ...
    def embed(self, text: str) -> list[float]: ...
    def search(
        self,
        query: str,
        source_type: str | None = ...,
        kind: str | None = ...,
        created_after: int | None = ...,
        status: str | None = ...,
        rerank_depth: int = ...,
        use_graph_arm: bool = ...,
        alpha: float | None = ...,
        pool_n: int | None = ...,
        explain: bool = ...,
        attributes: list[tuple[str, str]] | None = ...,
        # 0.8.20 Slice 15b fix-2 (R-20-NV / R-20-RV) — optional VALIDITY view.
        # `None` (default) is the strict view: active-only, non-superseded, and
        # valid AT QUERY TIME. The EXISTENCE flags (`include_superseded` /
        # `include_inactive`) raise `InvalidArgumentError` on this path rather
        # than being silently ignored. See `fathomdb.engine.Engine.search`.
        view: ReadView | None = ...,
        limit: int = ...,
    ) -> SearchResult: ...
    def search_projected_text(
        self,
        query: str,
        name: str,
        source_type: str | None = ...,
        kind: str | None = ...,
        created_after: int | None = ...,
        status: str | None = ...,
        attributes: list[tuple[str, str]] | None = ...,
        view: ReadView | None = ...,
        limit: int = ...,
    ) -> SearchResult: ...
    # 0.8.18 Slice 5 (R-VEQ-4) — text-only / FTS-only path; takes the same
    # optional validity view as `search` (0.8.20 Slice 15b fix-2).
    def search_text_only(
        self, query: str, view: ReadView | None = ..., limit: int = ...
    ) -> SearchResult: ...
    def dense_disabled(self) -> bool: ...
    def dense_disabled_reason(self) -> str | None: ...
    def vector_equivalence_refusal_count(self) -> int: ...
    # 0.8.8 Slice 15 (OPP-9) — opt-in local telemetry capture.
    def enable_telemetry(self, sink_path: str) -> None: ...
    def last_telemetry_query_id(self) -> str | None: ...
    def record_feedback(
        self,
        query_id: str,
        relevant_ids: list[int],
        irrelevant_ids: list[int],
        label_source: str,
    ) -> None: ...
    def close(self) -> None: ...
    def drain(self, timeout_s: float = ...) -> None: ...
    def ingest_with_extractor(
        self,
        cmd: list[str],
        documents: list[dict[str, str]],
    ) -> IngestWithExtractorReceipt:
        """G11 (Slice 15) — BYO-LLM ingest: spawn an external extraction harness
        speaking the fathomdb.extract.v1 protocol, extract entities + edges from
        documents, and write them to the store.

        ``cmd`` is argv (first element = program, rest = args).
        ``documents`` is a list of dicts with ``source_doc_id`` and ``body`` keys.
        """
        ...
    def consolidate_with_provider(
        self,
        cmd: list[str],
        axes: list[dict[str, str]],
    ) -> ConsolidateReceipt:
        """0.8.12 Slice 15 (OPP-2) — consolidation / recency via a BYO-LLM
        harness speaking the fathomdb.consolidate.v1 protocol.

        ``cmd`` is argv (first element = program, rest = args).
        ``axes`` is a list of dicts with ``subject_logical_id`` and ``relation``
        keys (a `ConsolidateAxis`); each names one (subject, relation) cluster to
        consolidate.
        """
        ...
    def counters(self) -> CounterSnapshot: ...
    def set_profiling(self, enabled: bool) -> None: ...
    def set_slow_threshold_ms(self, value: int) -> None: ...
    def attach_logging_subscriber(
        self,
        logger: Any,
    ) -> None: ...

# Slice 20 (G5/G6) — graph traversal result types.

class ExpandedNode:
    """One node reached by BFS traversal that is NOT in the search hit set."""

    node: NodeRecord
    hop_count: int

class SearchExpandResult:
    """G6 result: original search hits + graph-expanded neighbors.

    Deduplication rule: a node in ``search_hits`` will NOT appear in
    ``expanded`` (search score takes priority).
    """

    search_hits: list[SearchHit]
    expanded: list[ExpandedNode]
    all_logical_ids: list[str]

class RuntimeConfiguration:
    @property
    def sqlite_mode(self) -> str: ...

class RuntimeConfigurationError(EngineError):
    reason: str
    requested_mode: str | None
    effective_mode: str | None
    sqlite_code: int | None

def admin_configure_runtime(sqlite_mode: str) -> RuntimeConfiguration: ...
def admin_configure(engine: Engine, name: str, body: str) -> WriteReceipt: ...
def transition(
    engine: Engine,
    logical_id: str,
    to_state: str,
    reason: str | None = ...,
) -> None: ...
def purge(engine: Engine, logical_id: str) -> None: ...

# 0.8.20 Slice 5d (R-20-E4) — the `erase_source` lifecycle verb + its report.
class EraseReport:
    source_ref: str
    nodes_excised: int
    edges_excised: int
    projections_invalidated: int

def erase_source(engine: Engine, source_id: str) -> EraseReport: ...

# 0.8.20 Slice 15d (R-20-PR) — projection registry verbs + their types.
class ProjectionSpec:
    name: str
    roles: list[str]
    fts: bool
    fts_tokenizer: str | None
    vector: bool
    vector_embedder: str | None
    # Engine-set READ METADATA: unavailable without a usable dense runtime;
    # otherwise embedding or ready according to outstanding projection work.
    vector_dense_readiness: DenseReadiness | None
    source: list[str] | None
    def __init__(
        self,
        name: str,
        roles: list[str],
        fts: bool = ...,
        fts_tokenizer: str | None = ...,
        vector: bool = ...,
        vector_embedder: str | None = ...,
        vector_dense_readiness: DenseReadiness | None = ...,
        source: list[str] | None = ...,
    ) -> None: ...

class ProjectionDelta:
    built: list[str]
    dropped: list[str]
    deferred: list[str]
    unchanged: bool
    # 0.8.20 Slice 22 (R-20-VC / TC-67) — node KINDS (not attribute names) the
    # vector writer can never commit. Empty, never absent.
    vector_unsupported_kinds: list[str]

class ProjectionRuntimeStatusEntry:
    name: str
    dense_readiness: ProjectionStatusDenseReadiness

class ProjectionRuntimeStatus:
    runtime_embedder_available: bool
    runtime_unavailability_reason: ProjectionRuntimeUnavailabilityReason
    projections: list[ProjectionRuntimeStatusEntry]
    vector_unsupported_kinds: list[str]

class EmbeddingReadiness:
    state: str
    usable_embedder: bool
    pending_count: int
    affected_kinds: list[str]
    code: str | None
    operation: str | None
    remediations: list[str]
    documentation_url: str | None

def configure_projections(
    engine: Engine, specs: list[ProjectionSpec], drop: list[str] | None = ...
) -> ProjectionDelta: ...
def read_projections(engine: Engine) -> list[ProjectionSpec]: ...
def read_projection_status(engine: Engine) -> ProjectionRuntimeStatus: ...
def read_projection_generation_status(engine: Engine) -> ProjectionGenerationStatusV1: ...
def read_mutation_projection_status(
    engine: Engine, request: dict[str, object]
) -> MutationProjectionStatusV1: ...
def read_embedding_readiness(engine: Engine) -> EmbeddingReadiness: ...
def read_get(
    engine: Engine, logical_id: str, view: ReadView | None = None
) -> NodeRecord | None: ...
def read_get_many(
    engine: Engine, logical_ids: list[str], view: ReadView | None = None
) -> list[NodeRecord | None]: ...
def read_collection(
    engine: Engine,
    collection: str,
    after_id: int | None = ...,
    limit: int = ...,
) -> list[OpStoreRow]: ...
def read_mutations(
    engine: Engine,
    collection: str,
    after_id: int | None = ...,
    limit: int = ...,
) -> list[OpStoreRow]: ...
def read_list(
    engine: Engine,
    kind: str,
    predicates: list[dict[str, Any]] | None = ...,
    limit: int = ...,
    view: ReadView | None = ...,
) -> list[NodeRecord]: ...
def read_list_filter(
    engine: Engine,
    kind: str,
    terms: list[dict[str, Any]] | None = ...,
    limit: int = ...,
    view: ReadView | None = ...,
) -> list[NodeRecord]: ...
def read_canonical_page(
    engine: Engine,
    kind: str,
    context: FrozenReadContextV1,
    limit: int,
    cursor: str | None = ...,
    schema_version: int = ...,
) -> NodePageV1: ...
def read_operational_state(
    engine: Engine,
    collection: str,
    record_key: str,
    context: FrozenReadContextV1 | None = ...,
) -> OperationalStateRecordV1 | None: ...
def read_operational_state_page(
    engine: Engine,
    collection: str,
    context: FrozenReadContextV1,
    limit: int,
    cursor: str | None = ...,
    schema_version: int = ...,
) -> OperationalStatePageV1: ...
def crossed_boundary_since(
    engine: Engine,
    since: int,
    view: ReadView | None = ...,
) -> list[BoundaryCrossing]: ...
def graph_neighbors(
    engine: Engine,
    logical_id: str,
    depth: int,
    direction: str,
    view: ReadView | None = ...,
) -> list[NodeRecord]:
    """G5 — bounded BFS from ``logical_id`` over ``canonical_edges``.

    ``depth`` must be 1–3; raises ``InvalidArgumentError`` for depth > 3.
    ``direction`` is one of ``"outgoing"``, ``"incoming"``, or ``"both"``.
    Returns nodes reachable within ``depth`` hops, hard-capped at 50.
    Valid-time filter: edges with ``t_invalid`` in the past are not traversed.
    """
    ...

def search_expand(
    engine: Engine,
    query: str,
    depth: int,
    source_type: str | None = ...,
    kind: str | None = ...,
    created_after: int | None = ...,
    status: str | None = ...,
    search_limit: int = ...,
) -> SearchExpandResult:
    """G6 — FTS/vector search followed by bounded BFS expansion.

    Runs ``search(query, ...)`` (G1), then expands each hit node via
    ``graph_neighbors(depth, both)``. Nodes that are both search hits
    and traversal neighbors appear only in ``search_hits`` (deduplicated).
    """
    ...

def rerank(
    query: str,
    passages: list[dict[str, Any]],
    rerank_depth: int,
    alpha: float | None = ...,
    pool_n: int | None = ...,
) -> list[dict[str, Any]]:
    """0.8.2 Slice E2 — standalone CE rerank over an arbitrary passage list.

    Each ``passages`` entry is ``{"id": int, "body": str, "score": float}``
    (``score`` = the caller's fused/RRF score). Returns the reranked order as
    ``[{"id": int, "score": float, "ce_score": float | None}]`` where ``score`` is
    the CE-blended score and ``ce_score`` is the per-candidate ``sigmoid(ce_logit)``
    (None outside the reranked pool). ``rerank_depth == 0`` OR an empty list returns
    the input order with input scores, byte-identical (no model load, no network).

    0.8.5 (EXP-0): ``alpha`` (default 0.3, clamped to [0,1]) is the CE-blend weight
    and ``pool_n`` (default = ``rerank_depth``) is the reranked-pool size. Omitting
    both reproduces the pre-slice α=0.3 blend; ``alpha=1.0, pool_n=10`` is the
    measured-parity config. Unlike ``Engine.search(rerank_depth=...)`` — which
    reranks the engine's own capped text pool — this reranks the caller-supplied
    pool with the identical cross-encoder.
    """
    ...

def embed_batch_cls(texts: list[str]) -> list[list[float]]:
    """V-3 dense-encoder path — CLS-pooled batch embed of ``texts``.

    Embeds each string with the pinned default bge-small weights using **CLS
    pooling** + L2-normalization (distinct from ``Engine.embed()``, which uses
    the engine's default Mean pooling), honoring ``FATHOMDB_EMBED_DEVICE``.
    Returns one ``list[float]`` per input, in input order; an empty input list
    returns ``[]``. Requires a wheel built with the ``default-embedder`` (or
    ``embed-cuda``) feature; otherwise raises ``EmbedderNotConfiguredError``.
    """
    ...

class EngineError(Exception): ...

class FrozenReadError(EngineError):
    reason: str
    field_path: str
    def __init__(self, message: str, *, reason: str, field_path: str) -> None: ...

class EvidenceError(EngineError):
    reason: str
    field_path: str
    def __init__(self, message: str, *, reason: str, field_path: str) -> None: ...

class DependencyTraceError(EngineError):
    code: str
    reason: str
    field_path: str
    def __init__(self, message: str, *, reason: str, field_path: str) -> None: ...

class GraphExpansionError(EngineError):
    code: str
    reason: str
    field_path: str
    def __init__(self, message: str, *, reason: str, field_path: str) -> None: ...

class PageError(EngineError):
    reason: str
    field_path: str
    def __init__(self, message: str, *, reason: str, field_path: str) -> None: ...

class StorageError(EngineError): ...
class ProjectionError(EngineError): ...
class VectorError(EngineError): ...
class KindNotVectorIndexedError(VectorError): ...
class EmbedderError(EngineError): ...

class EmbedDevicePolicyError(EmbedderError):
    kind: str
    ordinal: int | None
    def __init__(
        self,
        *args: Any,
        kind: str = ...,
        ordinal: int | None = ...,
    ) -> None: ...

class EmbedderNotConfiguredError(EmbedderError): ...

class EmbedderRequiredError(EmbedderError):
    code: Literal["FDB_EMBEDDER_REQUIRED"]
    operation: EmbeddingOperation
    state: Literal["blocked"]
    remediations: list[str]
    documentation_url: str
    def __init__(
        self,
        *args: Any,
        code: Literal["FDB_EMBEDDER_REQUIRED"] = ...,
        operation: EmbeddingOperation = ...,
        state: Literal["blocked"] = ...,
        remediations: list[str] = ...,
        documentation_url: str = ...,
    ) -> None: ...

class SchedulerError(EngineError): ...
class OpStoreError(EngineError): ...
class WriteValidationError(EngineError): ...
class SchemaValidationError(EngineError): ...
class OverloadedError(EngineError): ...
class ClosingError(EngineError): ...

class ProvenanceError(EngineError):
    reason: str
    field_path: str
    def __init__(self, *args: Any, reason: str = ..., field_path: str = ...) -> None: ...

class DependencyError(EngineError):
    reason: str
    field_path: str
    def __init__(self, *args: Any, reason: str = ..., field_path: str = ...) -> None: ...

class DependencyClosureError(EngineError):
    reason: str
    field_path: str
    def __init__(self, *args: Any, reason: str = ..., field_path: str = ...) -> None: ...

class ActuationError(EngineError):
    reason: str
    field_path: str
    def __init__(self, *args: Any, reason: str = ..., field_path: str = ...) -> None: ...

class DatabaseLockedError(EngineError):
    holder_pid: int | None
    def __init__(self, *args: Any, holder_pid: int | None = ...) -> None: ...

class CorruptionError(EngineError):
    kind: str
    stage: str
    recovery_hint_code: str
    doc_anchor: str
    def __init__(
        self,
        *args: Any,
        kind: str = ...,
        stage: str = ...,
        recovery_hint_code: str = ...,
        doc_anchor: str = ...,
    ) -> None: ...

class IncompatibleSchemaVersionError(EngineError): ...
class MigrationError(EngineError): ...

class EmbedderIdentityMismatchError(EngineError):
    stored_name: str
    stored_revision: str
    supplied_name: str
    supplied_revision: str
    def __init__(
        self,
        *args: Any,
        stored_name: str = ...,
        stored_revision: str = ...,
        supplied_name: str = ...,
        supplied_revision: str = ...,
    ) -> None: ...

class EmbedderDimensionMismatchError(EngineError):
    stored: int
    supplied: int
    def __init__(self, *args: Any, stored: int = ..., supplied: int = ...) -> None: ...

class RerankerDevicePolicyError(EmbedderError):
    kind: str
    ordinal: int | None
    def __init__(self, *args: Any, kind: str = ..., ordinal: int | None = ...) -> None: ...

# G11 (Slice 15) — BYO-LLM extraction harness protocol error.
class ExtractorError(EngineError): ...

# 0.8.12 Slice 15 (OPP-2) — consolidation harness protocol error.
class ConsolidatorError(EngineError): ...

# G4 (Slice 35) — filter predicate construction error (non-allowlisted path).
class InvalidFilterError(EngineError): ...

# Slice 20 — depth > 3 or other argument validation failure.
class InvalidArgumentError(EngineError): ...

# 0.8.18 Slice 5 (#5 vector-equivalence probe) — query-time dense-refusal leaf.
class VectorEquivalenceMismatchError(EngineError):
    reason: str | None
    def __init__(self, *args: Any, reason: str | None = ...) -> None: ...

# OPP-12 Phase-1 (0.8.19 Slice 10) — lifecycle-verb typed errors. Parity-safe
# field names (S7): `from_state`/`to_state` (never `from`, a Python keyword).
class IllegalTransitionError(EngineError):
    from_state: str
    to_state: str
    legal: list[str]
    def __init__(
        self,
        *args: Any,
        from_state: str = ...,
        to_state: str = ...,
        legal: list[str] = ...,
    ) -> None: ...

class NotLifecycleAddressableError(EngineError):
    id_space: str
    def __init__(self, *args: Any, id_space: str = ...) -> None: ...

# 0.8.20 Slice 5b (R-20-E5) — an erasure verb deleted its rows but could not
# complete the erasure at rest (typically a WAL checkpoint blocked by a
# concurrent reader). `stage` names the uncompleted step.
class ErasureIncompleteError(EngineError):
    stage: str
    detail: str
    def __init__(self, *args: Any, stage: str = ..., detail: str = ...) -> None: ...

# 0.8.20 Slice 15d (R-20-PR) — `configure_projections` refused a DESTRUCTIVE
# change to a live projection `name` (a role removal or tokenizer/embedder swap)
# that was NOT accompanied by an explicit `drop`. `delta` names WHAT changed; the
# caller re-issues with `drop: [name]` to consciously rebuild.
class ProjectionDestructiveError(EngineError):
    name: str
    delta: str
    def __init__(self, *args: Any, name: str = ..., delta: str = ...) -> None: ...

class ProjectionGenerationError(EngineError):
    reason: str
    field_path: str
    def __init__(self, *args: Any, reason: str = ..., field_path: str = ...) -> None: ...
