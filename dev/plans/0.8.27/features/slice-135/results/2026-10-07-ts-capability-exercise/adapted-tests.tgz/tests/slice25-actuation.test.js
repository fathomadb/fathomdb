import assert from "node:assert/strict";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { ActuationError, Engine } from "fathomdb";
const sharedFixture = JSON.parse(readFileSync(join(process.cwd(), "../../dev/fixtures/slice25-actuation-conformance-v1.json"), "utf8"));
function request(operationId = "typescript-actuation") {
    return {
        schemaVersion: 1,
        operationId,
        operations: [
            {
                type: "put_canonical_node",
                record: {
                    kind: "doc",
                    body: "source body",
                    sourceId: "source-a",
                    logicalId: "source",
                    provenance: {
                        schemaVersion: 1,
                        role: "canonical",
                        artifactRevisionId: "source-r1",
                        sourceVersionId: "version-r1",
                    },
                },
            },
        ],
    };
}
test("actuation commits and exact replay returns the terminal receipt", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request();
    const receipt = await engine.actuate(input);
    assert.equal(receipt.outcome, "committed");
    assert.equal(receipt.resultingWriteBoundary, "1");
    assert.deepEqual(receipt.affectedRevisionIds, ["source-r1"]);
    assert.deepEqual(await engine.actuate(input), receipt);
    await engine.close();
});
test("actuation preserves embedded-NUL source identity", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-nul-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    await engine.write([{ kind: "ordinary", body: "ordinary", sourceId: "source\0id" }]);
    const input = request("typescript-nul-source");
    const record = input.operations[0].record;
    record.sourceId = "source\0id";
    const receipt = await engine.actuate(input);
    assert.equal(receipt.outcome, "committed");
    assert.deepEqual(await engine.actuate(input), receipt);
    await engine.close();
});
test("actuation rejects an unpaired surrogate at the canonical nested path", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-surrogate-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-surrogate-source");
    const record = input.operations[0].record;
    record.sourceId = `source${String.fromCharCode(0xd800)}id`;
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "nested_request_invalid" &&
        error.fieldPath === "/operations/0/record/sourceId");
    await engine.close();
});
test("actuation surrogate guard preserves schema precedence", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-surrogate-schema-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-surrogate-schema");
    input.schemaVersion = 2;
    const record = input.operations[0].record;
    record.sourceId = `source${String.fromCharCode(0xd800)}id`;
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unsupported_schema_version" &&
        error.fieldPath === "/schemaVersion");
    await engine.close();
});
test("actuation surrogate guard preserves unknown-field precedence", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-surrogate-unknown-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-surrogate-unknown");
    input.aUnknown = true;
    const record = input.operations[0].record;
    record.sourceId = `source${String.fromCharCode(0xd800)}id`;
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unknown_field" &&
        error.fieldPath === "/aUnknown");
    await engine.close();
});
test("actuation surrogate guard preserves top-level ID taxonomy", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-surrogate-id-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request(`operation${String.fromCharCode(0xd800)}id`);
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "operation_id_invalid" &&
        error.fieldPath === "/operationId");
    await engine.close();
});
test("shared all-variant fixture has exact receipt and digest", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-shared-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const receipt = await engine.actuate(sharedFixture.request);
    assert.equal(receipt.requestSha256, sharedFixture.expected.requestSha256);
    assert.equal(receipt.outcome, sharedFixture.expected.outcome);
    assert.deepEqual(receipt.affectedRevisionIds, sharedFixture.expected.affectedRevisionIds);
    assert.equal(receipt.resultingWriteBoundary, sharedFixture.expected.resultingWriteBoundary);
    assert.equal(receipt.resultingDependencyGeneration, sharedFixture.expected.resultingDependencyGeneration);
    assert.deepEqual(receipt.pendingProjectionWriteCursors, sharedFixture.expected.pendingProjectionWriteCursors);
    assert.deepEqual(receipt.closureOperationIds, sharedFixture.expected.closureOperationIds);
    assert.deepEqual(await engine.actuate(sharedFixture.request), receipt);
    await engine.close();
});
test("actuation errors preserve reason and canonical field path", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-error-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = { ...request("unknown-field"), zUnknown: true };
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unknown_field" &&
        error.fieldPath === "/zUnknown");
    await engine.close();
});
test("actuation rejects unknown nested record fields", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-record-error-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("unknown-record-field");
    const record = input.operations[0].record;
    record.zUnknown = true;
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unknown_field" &&
        error.fieldPath === "/operations/0/record/zUnknown");
    await engine.close();
});
test("actuation rejects an own top-level __proto__ field without writing", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-proto-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-proto");
    Object.defineProperty(input, "__proto__", {
        value: {},
        enumerable: true,
        configurable: true,
        writable: true,
    });
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unknown_field" &&
        error.fieldPath === "/__proto__");
    assert.equal((await engine.search("source body")).results.length, 0);
    await engine.close();
});
test("actuation rejects an own nested __proto__ field without writing", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-nested-proto-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-nested-proto");
    const record = input.operations[0].record;
    Object.defineProperty(record, "__proto__", {
        value: {},
        enumerable: true,
        configurable: true,
        writable: true,
    });
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "unknown_field" &&
        error.fieldPath === "/operations/0/record/__proto__");
    assert.equal((await engine.search("source body")).results.length, 0);
    await engine.close();
});
test("actuation validates operation count before nested operation data", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-count-precedence-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-count-precedence");
    const invalid = structuredClone(input.operations[0]);
    if (invalid.type === "put_canonical_node")
        invalid.record.sourceId = "";
    input.operations = [invalid, ...Array.from({ length: 128 }, () => input.operations[0])];
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "operation_count_invalid" &&
        error.fieldPath === "/operations");
    await engine.close();
});
test("actuation validates policy ID before nested operation data", async () => {
    const dir = mkdtempSync(join(tmpdir(), "fathomdb-actuation-policy-precedence-"));
    const engine = await Engine.open(join(dir, "actuation.fathom"));
    const input = request("typescript-policy-precedence");
    input.decisionPolicyId = "_invalid";
    const operation = input.operations[0];
    if (operation.type === "put_canonical_node")
        operation.record.sourceId = "";
    await assert.rejects(engine.actuate(input), (error) => error instanceof ActuationError &&
        error.reason === "decision_policy_id_invalid" &&
        error.fieldPath === "/decisionPolicyId");
    await engine.close();
});
