import assert from "node:assert/strict";
import test from "node:test";
import { Engine, FrozenReadError, } from "fathomdb";
import { freshDbPath } from "./helpers.js";
const SOURCE_ID = "ts-test:slice35-frozen";
test("frozen read context binds eligibility and rejects drift", async () => {
    const engine = await Engine.open(freshDbPath(), { useDefaultEmbedder: false });
    try {
        await engine.write([
            { kind: "doc", body: "needle allowed", logicalId: "allowed", sourceId: SOURCE_ID },
            { kind: "note", body: "needle excluded", logicalId: "excluded", sourceId: SOURCE_ID },
        ]);
        const requested = { schemaVersion: 1, view: {}, eligibility: { kind: "doc" } };
        const frozen = await engine.freezeReadContext(requested);
        assert.equal(frozen.context.view.validAsOf, frozen.effectiveValidAt);
        const first = await engine.searchFrozen("needle", frozen, { limit: 1 });
        assert.deepEqual(first.results.map((hit) => hit.id.value), ["allowed"]);
        await engine.write([
            { kind: "doc", body: "needle later", logicalId: "later", sourceId: SOURCE_ID },
        ]);
        await assert.rejects(() => engine.searchFrozen("needle", frozen), (error) => error instanceof FrozenReadError && error.reason === "state_drifted");
    }
    finally {
        await engine.close();
    }
});
test("frozen search expansion returns the governed union", async () => {
    const engine = await Engine.open(freshDbPath(), { useDefaultEmbedder: false });
    try {
        await engine.write([
            { kind: "doc", body: "expand needle", logicalId: "root", sourceId: SOURCE_ID },
        ]);
        const frozen = await engine.freezeReadContext({
            schemaVersion: 1,
            view: {},
            eligibility: { kind: "doc" },
        });
        const result = await engine.searchExpandFrozen("expand needle", frozen, 0);
        assert.deepEqual(result.allLogicalIds, ["root"]);
        assert.deepEqual(result.expanded, []);
    }
    finally {
        await engine.close();
    }
});
test("frozen explanation maps and disabled control is unchanged", async () => {
    const engine = await Engine.open(freshDbPath(), { useDefaultEmbedder: false });
    try {
        await engine.write([
            {
                kind: "doc",
                body: "typescript frozen explanation needle",
                logicalId: "explained",
                sourceId: SOURCE_ID,
            },
        ]);
        const frozen = await engine.freezeReadContext({ schemaVersion: 1, view: {}, eligibility: {} });
        const plain = await engine.searchFrozen("frozen explanation", frozen, { explain: false });
        const explained = await engine.searchFrozen("frozen explanation", frozen, { explain: true });
        assert.equal(plain.explanation, null);
        assert.ok(explained.explanation?.correlationId?.startsWith("x"));
        assert.deepEqual(plain.results, explained.results);
    }
    finally {
        await engine.close();
    }
});
test("frozen authentication precedes query, shape, and range validation", async () => {
    const engine = await Engine.open(freshDbPath(), { useDefaultEmbedder: false });
    try {
        const frozen = await engine.freezeReadContext({ schemaVersion: 1, view: {}, eligibility: {} });
        const malformed = { ...frozen, token: `${frozen.token}0`, unexpected: true };
        await assert.rejects(() => engine.searchFrozen("", malformed, { limit: -1, unexpected: true }), (error) => error instanceof FrozenReadError && error.reason === "token_malformed");
        await assert.rejects(() => engine.searchExpandFrozen("", malformed, -1, { searchLimit: -1 }), (error) => error instanceof FrozenReadError && error.reason === "token_malformed");
    }
    finally {
        await engine.close();
    }
});
