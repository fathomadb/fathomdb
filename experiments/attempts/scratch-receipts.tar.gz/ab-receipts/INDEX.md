# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-17T00:03:08Z | comp-02b-latency | comp-02b-latency-20261017T0003Z-4f96fad0 | complete | 100 | f9ae5c27bb13c68217b27cc1fcae19945c66d131 | 0.0 | body-text-only=8.871; projected-c01=31.267; projected-c10=9.383; projected-c33=8.457; projected-single-term=2.818; projected-unfiltered=2.974 |  |
