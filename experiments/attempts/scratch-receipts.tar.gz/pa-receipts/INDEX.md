# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-17T02:56:39Z | comp-03-retrieval-sweep | comp-03-retrieval-sweep-20261017T0256Z-78c3c36d | complete | 500 | 9332c2468d2e1a7e55bd42da192d48a6a75df681 | 0.0 | clauses={'a': True, 'b': True, 'c': True}; decision=adopt; questions=500 |  |
| 2026-10-17T03:08:55Z | comp-03-hermes-answer | comp-03-hermes-answer-20261017T0308Z-0f2856e9 | complete | 60 | 9332c2468d2e1a7e55bd42da192d48a6a75df681 | 2.5838 | accuracy={'fathomdb-fts-pack': 0.9333333333333333, 'fathomdb-hybrid-pack': 0.9}; difference=0.03333333333333333; n=60 |  |
