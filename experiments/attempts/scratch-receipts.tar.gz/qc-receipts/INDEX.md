# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-17T11:42:36Z | comp-02b-latency | comp-02b-latency-20261017T1142Z-2412d988 | complete | 100 | fc26c75fff7189e00450b79d49ef34c6e85bb307 | 0.0 | body-text-only=3.309; projected-c01=6.577; projected-c10=3.786; projected-c33=3.104; projected-single-term=1.045; projected-unfiltered=2.823 |  |
