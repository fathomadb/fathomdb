# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-17T12:16:03Z | comp-03-hermes-answer | comp-03-hermes-answer-20261017T1216Z-3bd3546c | complete | 250 | fc26c75fff7189e00450b79d49ef34c6e85bb307 | 7.2777 | accuracy={'fathomdb-fts-pack': 0.856, 'lancedb-fts': 0.784}; difference=0.072; n=250 |  |
