# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-16T14:06:42Z | comp-03-retrieval-sweep | comp-03-retrieval-sweep-20261016T1406Z-17773486 | complete | 500 | 0edd7a078ca95605ff70665b658eddf9546158d5 | 0.0 | clauses={'a': True, 'b': True, 'c': True}; decision=adopt; questions=500 |  |
| 2026-10-16T14:22:26Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1422Z-c807ed90 | complete | 60 | 0edd7a078ca95605ff70665b658eddf9546158d5 | 2.3376 | accuracy={'fathomdb-fts': 0.8166666666666667, 'fathomdb-hybrid': 0.8}; difference=0.016666666666666666; n=60 |  |
| 2026-10-16T16:09:34Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1609Z-22869ddc | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.339 | accuracy={'fathomdb-fts': 0.8166666666666667, 'fathomdb-hybrid': 0.8666666666666667}; difference=-0.05; n=60 |  |
| 2026-10-16T16:09:38Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1609Z-1c856c71 | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.3372 | accuracy={'fathomdb-fts': 0.8166666666666667, 'fathomdb-hybrid': 0.8333333333333334}; difference=-0.016666666666666666; n=60 |  |
| 2026-10-16T16:10:37Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1610Z-33d78241 | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.3691 | accuracy={'fathomdb-fts': 0.85, 'fathomdb-hybrid': 0.8333333333333334}; difference=0.016666666666666666; n=60 |  |
| 2026-10-16T17:00:17Z | comp-02b-latency | comp-02b-latency-20261016T1700Z-4f96fad0 | complete | 100 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 0.0 | body-text-only=8.759; projected-c01=29.809; projected-c10=9.083; projected-c33=8.225; projected-single-term=2.783; projected-unfiltered=2.862 |  |
| 2026-10-16T17:25:16Z | comp-03-retrieval-sweep | comp-03-retrieval-sweep-20261016T1725Z-17773486 | complete | 500 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 0.0 | clauses={'a': True, 'b': True, 'c': True}; decision=adopt; questions=500 |  |
| 2026-10-16T17:32:32Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1732Z-50579949 | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.3414 | accuracy={'fathomdb-fts': 0.8833333333333333, 'fathomdb-hybrid': 0.8333333333333334}; difference=0.05; n=60 |  |
| 2026-10-16T17:32:57Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1732Z-33d78241 | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.364 | accuracy={'fathomdb-fts': 0.8333333333333334, 'fathomdb-hybrid': 0.8166666666666667}; difference=0.016666666666666666; n=60 |  |
| 2026-10-16T17:47:00Z | comp-03-hermes-answer | comp-03-hermes-answer-20261016T1747Z-4e56afa9 | complete | 60 | fcef83b84013a47268d951a3a9ba161c2a80b99c | 3.3398 | accuracy={'fathomdb-fts': 0.8833333333333333, 'fathomdb-hybrid': 0.8666666666666667}; difference=0.016666666666666666; n=60 |  |
