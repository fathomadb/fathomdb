# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-16T23:08:45Z | comp-02b-latency | comp-02b-latency-20261016T2308Z-4f96fad0 | complete | 100 | f9ae5c27bb13c68217b27cc1fcae19945c66d131 | 0.0 | body-text-only=9.426; projected-c01=32.236; projected-c10=9.697; projected-c33=8.59; projected-single-term=3.112; projected-unfiltered=3.089 |  |
| 2026-10-17T00:02:06Z | comp-02b-latency | comp-02b-latency-20261017T0002Z-4f96fad0 | complete | 100 | f9ae5c27bb13c68217b27cc1fcae19945c66d131 | 0.0 | body-text-only=5.545; projected-c01=12.163; projected-c10=6.578; projected-c33=5.207; projected-single-term=0.878; projected-unfiltered=2.823 |  |
