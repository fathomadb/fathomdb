# Experiment index

GENERATED FROM `index.jsonl` — do NOT hand-edit. Regenerate with `experiments/_lib.regen_index_md()`.

| ts | experiment | run_id | verdict | n | git_sha | cost_usd | headline | review |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-10-17T12:20:44Z | comp-02b-latency | comp-02b-latency-20261017T1220Z-2412d988 | complete | 100 | fc26c75fff7189e00450b79d49ef34c6e85bb307 | 0.0 | body-text-only=3.26; projected-c01=11.982; projected-c10=6.222; projected-c33=3.122; projected-single-term=0.979; projected-unfiltered=2.81 |  |
| 2026-10-17T12:23:08Z | comp-02b-latency | comp-02b-latency-20261017T1223Z-2412d988 | complete | 100 | fc26c75fff7189e00450b79d49ef34c6e85bb307 | 0.0 | body-text-only=3.289; projected-c01=6.797; projected-c10=4.054; projected-c33=2.999; projected-single-term=0.946; projected-unfiltered=2.748 |  |
| 2026-10-17T12:25:31Z | comp-02b-latency | comp-02b-latency-20261017T1225Z-2412d988 | complete | 100 | fc26c75fff7189e00450b79d49ef34c6e85bb307 | 0.0 | body-text-only=3.46; projected-c01=30.853; projected-c10=5.895; projected-c33=3.248; projected-single-term=0.945; projected-unfiltered=2.858 |  |
